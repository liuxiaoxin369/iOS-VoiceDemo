//
//  ViewController.h
//  YuYinTest
//
//  Created by 柳恒博 on 16/6/23.
//  Copyright © 2016年 柳恒博. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <iflyMSC/iflyMSC.h>

//引入语音识别类
@class IFlyDataUploader;
@class IFlySpeechUnderstander;

@interface ViewController : UIViewController <IFlySpeechRecognizerDelegate>

@property (nonatomic, strong) IFlySpeechUnderstander *iflySpeechUnderstander;
@property (strong, nonatomic) IBOutlet UITextField *TF;
@property (nonatomic, strong) NSString *result;
@property (nonatomic, strong) NSString *str_result;
@property (nonatomic, assign) BOOL isCancled;

- (IBAction)start:(UIButton *)sender;
- (IBAction)end:(UIButton *)sender;


@end

